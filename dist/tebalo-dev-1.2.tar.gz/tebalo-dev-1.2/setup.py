from setuptools import setup
 
setup(
    name='tebalo-dev',
    version='1.2',
    packages=['tebalo-dev'],
)
