from setuptools import setup
 
setup(
    name='tebalodev',
    version='1.4',
    packages=['tebalodev'],
)
