from setuptools import setup
 
setup(
    name='tebalo',
    version='0.8',
    packages=['tebalo']
)
