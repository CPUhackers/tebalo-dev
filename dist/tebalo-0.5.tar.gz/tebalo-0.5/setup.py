from setuptools import setup
 
setup(
    name='tebalo',
    version='0.5',
    scripts=['utils.py']
)
