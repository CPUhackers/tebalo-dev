from setuptools import setup
 
setup(
    name='tebalo',
    version='0.3',
    scripts=['tebalo']
)
