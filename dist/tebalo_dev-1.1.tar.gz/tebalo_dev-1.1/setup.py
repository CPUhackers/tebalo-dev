from setuptools import setup
 
setup(
    name='tebalo_dev',
    version='1.1',
    packages=['tebalo'],
)
