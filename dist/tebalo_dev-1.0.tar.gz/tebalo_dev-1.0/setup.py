from setuptools import setup
 
setup(
    name='tebalo_dev',
    version='1.0',
    packages=['tebalo'],
)
