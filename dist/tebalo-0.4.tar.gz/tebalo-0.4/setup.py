from setuptools import setup
 
setup(
    name='tebalo',
    version='0.4',
    scripts=['utils.py']
)
