from setuptools import setup
 
setup(
    name='tebalo',
    version='0.2',
    scripts=['tebalo']
)
