from setuptools import setup
 
setup(
    name='tebalo',
    version='0.9',
    packages=['tebalo']
)
