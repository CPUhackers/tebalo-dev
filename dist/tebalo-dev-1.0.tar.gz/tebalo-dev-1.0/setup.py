from setuptools import setup
 
setup(
    name='tebalo-dev',
    version='1.0',
    packages=['tebalo'],
)
