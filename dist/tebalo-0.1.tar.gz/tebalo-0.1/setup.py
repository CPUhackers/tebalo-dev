from setuptools import setup
 
setup(
    name='tebalo',
    version='0.1',
    scripts=['main']
)
