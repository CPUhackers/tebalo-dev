from setuptools import setup
 
setup(
    name='tebalo',
    version='0.7',
    packages=['tebalo']
)
